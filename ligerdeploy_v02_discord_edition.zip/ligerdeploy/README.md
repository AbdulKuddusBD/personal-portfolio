# LigerDeploy v0.2 — Discord Bot Hosting Edition

LigerDeploy is a self-hosted Python bot/app hosting panel. Version 0.2 is focused on Discord bot hosting while still supporting Telegram bots, MTProto userbots, FastAPI, Flask, Django, schedulers, workers, and custom Python scripts.

> Goal: a simple self-owned alternative-style bot hosting panel where users can upload files or ZIPs, install `requirements.txt`, add secrets, run a startup command, and view logs from the browser.

## Highlights

- Public landing page
- Session-based login/register
- Admin and user roles
- User quotas: max projects, storage MB, upload MB
- Dashboard with online/offline/crashed stats
- Project manager for bots and Python apps
- Discord-first project type
- Startup command validation
- Per-project virtualenv installer
- Browser file manager
- Safe ZIP extraction
- Environment variables with masked secret display
- PID/log based process manager
- stdout/stderr/install logs
- Starter templates for Discord, Telegram, FastAPI, Flask, Django, UserBot and scheduler apps
- SQLite MVP database
- Deployment examples for systemd and Nginx

## Requirements

- Linux VPS recommended
- Python 3.10+
- SQLite
- `python3-venv`
- Firewall access to port 8080, or Nginx reverse proxy

Ubuntu packages:

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip sqlite3 unzip
```

## Installation

```bash
unzip ligerdeploy_v02_discord_edition.zip
cd ligerdeploy
python3 -m venv .panel-venv
source .panel-venv/bin/activate
pip install -r requirements.txt
python scripts/install.py
python run.py
```

Open:

```text
http://127.0.0.1:8080
```

On a VPS, `run.py` binds to `0.0.0.0:8080` by default. Open firewall:

```bash
sudo ufw allow 8080/tcp
sudo ufw reload
```

Then open:

```text
http://YOUR_SERVER_IP:8080
```

## Default admin

The installer asks for admin details. If you press Enter through prompts:

```text
Email: admin@example.com
Password: admin12345
```

Change this immediately.

## Permanent systemd service

Copy the deployment service and adjust paths/user:

```bash
sudo cp deployment/ligerdeploy.service /etc/systemd/system/ligerdeploy.service
sudo systemctl daemon-reload
sudo systemctl enable ligerdeploy
sudo systemctl start ligerdeploy
sudo systemctl status ligerdeploy
```

Logs:

```bash
sudo journalctl -u ligerdeploy -f
```

## Optional auto-restart watchdog

The app includes a one-shot watchdog script for projects with `auto_restart` enabled.

```bash
sudo cp deployment/ligerdeploy-watchdog.service /etc/systemd/system/
sudo cp deployment/ligerdeploy-watchdog.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now ligerdeploy-watchdog.timer
```

## Creating a Discord bot

1. Login.
2. Go to **Templates**.
3. Choose `discordpy-basic-bot`, `pycord-basic-bot`, `nextcord-basic-bot`, or `hikari-lightbulb-bot`.
4. Create the project.
5. Open **Environment**.
6. Add `DISCORD_TOKEN`.
7. Open **Project Details**.
8. Click **Install Requirements**.
9. Click **Start**.
10. Open **Logs** to verify the bot is online.

## Uploading your own bot ZIP

1. Create a blank **Discord Bot** project.
2. Open **Files**.
3. Upload your ZIP.
4. Click **Extract**.
5. Make sure `requirements.txt` exists in project root.
6. Add `DISCORD_TOKEN` and other secrets.
7. Set startup command, usually:

```bash
python bot.py
```

8. Install requirements and start.

## Allowed startup commands

Startup commands are parsed without shell execution and must start with one of:

```text
python, python3, uvicorn, gunicorn, hypercorn, daphne
```

Blocked shell operators:

```text
; && || | > < ` $()
```

Examples:

```bash
python bot.py
python main.py
uvicorn main:app --host 0.0.0.0 --port 8000
gunicorn myproject.wsgi:application --bind 0.0.0.0:8000
```

## Templates included

Discord:

- `discordpy-basic-bot`
- `pycord-basic-bot`
- `nextcord-basic-bot`
- `hikari-lightbulb-bot`

Telegram/UserBot/Python:

- `aiogram-basic-bot`
- `aiogram-fastapi-webhook`
- `telethon-userbot`
- `pyrogram-userbot`
- `fastapi-basic-api`
- `flask-basic-app`
- `django-basic-app`
- `apscheduler-worker`

## Security warning

This MVP runs uploaded Python code on the same host account as the panel process unless you isolate it yourself. Do not expose this as a public hosting business without container or user isolation.

Minimum public-production upgrades:

- Docker container per project
- CPU/RAM/storage limits
- Per-project network policy
- Non-root runtime user
- Malware scanning
- Abuse monitoring
- Rate limiting
- Reverse proxy isolation
- Secret rotation

## Abuse policy

Do not use LigerDeploy to host spam bots, unsolicited messaging, credential theft, scraping abuse, phishing, token stealers, malware, or any project that violates Discord, Telegram, or third-party platform terms.

## Project structure

```text
ligerdeploy/
├── app/
├── database/
├── deployment/
├── public/
├── resources/views/
├── scripts/
├── storage/
├── templates/
├── README.md
├── SECURITY.md
└── ROADMAP.md
```

## License

MIT License. See `LICENSE`.
