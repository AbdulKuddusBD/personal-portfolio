#!/usr/bin/env python3
"""One-shot auto-restart watchdog for LigerDeploy.

Run this from cron/systemd timer every minute if you want MVP auto_restart support:
    * * * * * cd /path/to/ligerdeploy && ./.panel-venv/bin/python scripts/watchdog.py
"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.core import database
from app.services import process_manager, project_service, activity_service


def main():
    rows = database.query_all("SELECT * FROM projects WHERE auto_restart = 1")
    for project in rows:
        status = process_manager.refresh_status(project)
        if status in {"crashed", "failed", "stopped"}:
            try:
                process_manager.start_project(project, None)
                activity_service.record(project["user_id"], project["id"], "watchdog.restart", "Auto-restarted project")
                print(f"restarted {project['id']} {project['slug']}")
            except Exception as exc:
                project_service.set_status(project["id"], "failed")
                process_manager.log_file(project["id"], "stderr.log").open("a", encoding="utf-8").write(f"\nWATCHDOG ERROR: {exc}\n")
                print(f"failed {project['id']} {exc}")

if __name__ == "__main__":
    main()
