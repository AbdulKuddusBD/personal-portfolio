#!/usr/bin/env python3
import shutil
import sqlite3
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.core import config


def check(name, ok, detail=""):
    print(("OK  " if ok else "FAIL") + f" {name}" + (f" - {detail}" if detail else ""))
    return ok


def main():
    ok = True
    ok &= check("Python 3.10+", sys.version_info >= (3, 10), sys.version.split()[0])
    ok &= check("SQLite available", sqlite3.sqlite_version_info is not None, sqlite3.sqlite_version)
    ok &= check("venv module", True)
    ok &= check("python binary", shutil.which(config.PANEL_PYTHON_BIN) is not None, config.PANEL_PYTHON_BIN)
    for path in [config.STORAGE_PATH, config.PROJECTS_PATH, config.LOGS_PATH, config.PIDS_PATH, config.UPLOADS_PATH]:
        path.mkdir(parents=True, exist_ok=True)
        ok &= check(str(path), path.exists() and path.is_dir())
    if not ok:
        sys.exit(1)

if __name__ == "__main__":
    main()
