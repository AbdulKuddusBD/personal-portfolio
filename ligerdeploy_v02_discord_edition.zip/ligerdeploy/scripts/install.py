#!/usr/bin/env python3
import getpass
import secrets
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.core import database, security
from app.core import config


def ensure_env():
    env_path = ROOT / ".env"
    if env_path.exists():
        return
    sample = (ROOT / ".env.example").read_text(encoding="utf-8")
    try:
        from cryptography.fernet import Fernet
        env_key = Fernet.generate_key().decode()
    except Exception:
        env_key = secrets.token_urlsafe(32)
    sample = sample.replace("change-this-session-secret", secrets.token_urlsafe(48))
    sample = sample.replace("generate-with-python-scripts-install", env_key)
    env_path.write_text(sample, encoding="utf-8")
    print("Created .env")


def ensure_dirs():
    for path in [config.STORAGE_PATH, config.PROJECTS_PATH, config.LOGS_PATH, config.PIDS_PATH, config.UPLOADS_PATH]:
        path.mkdir(parents=True, exist_ok=True)
    print("Created storage directories")


def create_admin():
    existing = database.query_one("SELECT id FROM users WHERE role = 'admin' LIMIT 1")
    if existing:
        print("Admin user already exists")
        return
    print("Create admin user")
    name = input("Name [Admin]: ").strip() or "Admin"
    email = input("Email [admin@example.com]: ").strip() or "admin@example.com"
    password = getpass.getpass("Password [admin12345]: ") or "admin12345"
    database.execute(
        """
        INSERT INTO users (name, email, password_hash, role, is_active, max_projects, max_storage_mb, max_upload_mb)
        VALUES (?, ?, ?, 'admin', 1, 0, 0, ?)
        """,
        (name, email.lower(), security.hash_password(password), config.MAX_UPLOAD_MB),
    )
    print(f"Admin created: {email}")


def main():
    if sys.version_info < (3, 10):
        print("Python 3.10+ is required")
        sys.exit(1)
    ensure_env()
    ensure_dirs()
    database.init_database()
    seed = ROOT / "database" / "seed.sql"
    if seed.exists():
        with database.get_connection() as conn:
            conn.executescript(seed.read_text(encoding="utf-8"))
            conn.commit()
    create_admin()
    print("\nLigerDeploy v0.2 Discord Bot Hosting Edition installed.")
    print("Run: python run.py")
    print("Open local: http://127.0.0.1:8080")
    print("Open public VPS: http://YOUR_SERVER_IP:8080 after binding to 0.0.0.0 and opening firewall.")
    print("Production note: run the panel as a non-root user and isolate bot/app processes.")


if __name__ == "__main__":
    main()
