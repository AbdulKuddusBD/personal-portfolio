#!/usr/bin/env python3
"""Future extension point for isolated project runners.

The MVP uses app.services.process_manager directly. This file documents the
stable contract expected from a future Docker/Supervisor/systemd runner:
start(project_id), stop(project_id), restart(project_id), status(project_id),
install_requirements(project_id), and stream_logs(project_id).
"""

from app.services.process_manager import validate_startup_command

__all__ = ["validate_startup_command"]
