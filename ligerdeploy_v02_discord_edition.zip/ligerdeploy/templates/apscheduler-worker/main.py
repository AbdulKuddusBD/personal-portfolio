from apscheduler.schedulers.blocking import BlockingScheduler
from datetime import datetime

scheduler = BlockingScheduler()

@scheduler.scheduled_job("interval", seconds=30)
def heartbeat():
    print(f"LigerDeploy scheduler heartbeat: {datetime.utcnow().isoformat()}Z", flush=True)

if __name__ == "__main__":
    print("Scheduler started", flush=True)
    scheduler.start()
