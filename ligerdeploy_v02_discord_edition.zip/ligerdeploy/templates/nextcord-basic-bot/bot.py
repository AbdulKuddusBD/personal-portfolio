import os
import nextcord
from nextcord.ext import commands

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("BOT_PREFIX", "!")

bot = commands.Bot(command_prefix=PREFIX, intents=nextcord.Intents.default())

@bot.event
async def on_ready():
    print(f"Nextcord bot ready as {bot.user}")

@bot.slash_command(description="Check bot latency")
async def ping(interaction: nextcord.Interaction):
    await interaction.response.send_message("Pong from LigerDeploy 🦁")

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN is missing. Add it from Environment Variables.")

bot.run(TOKEN)
