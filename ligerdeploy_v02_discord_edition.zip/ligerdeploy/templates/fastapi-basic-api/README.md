# FastAPI Basic API

Start with `uvicorn main:app --host 0.0.0.0 --port 8000`.
