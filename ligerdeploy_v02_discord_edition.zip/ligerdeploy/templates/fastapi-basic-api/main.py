from fastapi import FastAPI

app = FastAPI(title="LigerDeploy FastAPI Starter")

@app.get("/")
async def root():
    return {"message": "FastAPI app running on LigerDeploy"}
