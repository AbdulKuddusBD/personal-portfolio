import os
from pyrogram import Client, filters

api_id = int(os.getenv("API_ID", "0"))
api_hash = os.getenv("API_HASH")
session = os.getenv("SESSION_STRING")
if not api_id or not api_hash or not session:
    raise RuntimeError("API_ID, API_HASH, and SESSION_STRING are required")

app = Client(name="ligerdeploy-userbot", api_id=api_id, api_hash=api_hash, session_string=session)

@app.on_message(filters.command("ping", prefixes="."))
async def ping(client, message):
    await message.reply_text("pong from LigerDeploy")

print("Pyrogram userbot running. Use responsibly and follow Telegram ToS.")
app.run()
