import os
from telethon import TelegramClient, events
from telethon.sessions import StringSession

api_id = int(os.getenv("API_ID", "0"))
api_hash = os.getenv("API_HASH")
session = os.getenv("SESSION_STRING")
if not api_id or not api_hash or not session:
    raise RuntimeError("API_ID, API_HASH, and SESSION_STRING are required")

client = TelegramClient(StringSession(session), api_id, api_hash)

@client.on(events.NewMessage(pattern=r"^\.ping$"))
async def ping(event):
    await event.reply("pong from LigerDeploy")

client.start()
print("Telethon userbot running. Use responsibly and follow Telegram ToS.")
client.run_until_disconnected()
