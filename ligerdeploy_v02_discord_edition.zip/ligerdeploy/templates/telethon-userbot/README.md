# Telethon UserBot

Use only for legitimate personal automation. Do not spam, scrape, or violate Telegram ToS. Start with `python main.py`.
