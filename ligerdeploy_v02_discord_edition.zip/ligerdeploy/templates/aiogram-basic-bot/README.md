# Aiogram Basic Bot

Set `BOT_TOKEN`, install requirements, and start with `python main.py`.
