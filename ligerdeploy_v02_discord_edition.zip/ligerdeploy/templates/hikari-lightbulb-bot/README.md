# Hikari Lightbulb Bot

Startup command:

```bash
python bot.py
```

Add `DISCORD_TOKEN` from the LigerDeploy Environment page before starting.
