import os
import hikari
import lightbulb

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("BOT_PREFIX", "!")

bot = lightbulb.BotApp(token=TOKEN, prefix=PREFIX, intents=hikari.Intents.GUILDS)

@bot.listen(hikari.StartedEvent)
async def started(_: hikari.StartedEvent) -> None:
    print("Hikari Lightbulb bot started")

@bot.command
@lightbulb.command("ping", "Check bot latency")
@lightbulb.implements(lightbulb.SlashCommand)
async def ping(ctx: lightbulb.Context) -> None:
    await ctx.respond("Pong from LigerDeploy 🦁")

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN is missing. Add it from Environment Variables.")

bot.run()
