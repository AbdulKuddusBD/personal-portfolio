from django.http import HttpResponse
from django.urls import path

def home(request):
    return HttpResponse("Django app running on LigerDeploy")

urlpatterns = [path("", home)]
