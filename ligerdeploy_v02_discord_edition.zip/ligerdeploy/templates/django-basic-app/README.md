# Django Basic App

Start with `python manage.py runserver 0.0.0.0:8000` for development or `gunicorn siteapp.wsgi:application --bind 0.0.0.0:8000` after adding wsgi.
