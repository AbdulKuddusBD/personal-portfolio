import os
import discord
from discord.ext import commands

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("BOT_PREFIX", "!")

intents = discord.Intents.default()
intents.message_content = os.getenv("DISCORD_MESSAGE_CONTENT", "false").lower() == "true"
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} slash command(s)")
    except Exception as exc:
        print(f"Slash sync failed: {exc}")

@bot.command()
async def ping(ctx):
    await ctx.reply("Pong from LigerDeploy 🦁")

@bot.tree.command(name="ping", description="Check bot latency")
async def slash_ping(interaction: discord.Interaction):
    await interaction.response.send_message("Pong from LigerDeploy 🦁")

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN is missing. Add it from Environment Variables.")

bot.run(TOKEN)
