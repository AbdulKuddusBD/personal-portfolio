# discord.py Basic Bot

Startup command:

```bash
python bot.py
```

Add `DISCORD_TOKEN` from the LigerDeploy Environment page before starting. Enable privileged message content intent only if your bot needs prefix commands.
