import os
import discord
from discord.ext import commands

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("BOT_PREFIX", "!")

bot = commands.Bot(command_prefix=PREFIX, intents=discord.Intents.default())

@bot.event
async def on_ready():
    print(f"Pycord bot ready as {bot.user}")

@bot.slash_command(description="Check bot latency")
async def ping(ctx):
    await ctx.respond("Pong from LigerDeploy 🦁")

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN is missing. Add it from Environment Variables.")

bot.run(TOKEN)
