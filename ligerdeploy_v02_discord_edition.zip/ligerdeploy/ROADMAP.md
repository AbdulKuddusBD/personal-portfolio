# LigerDeploy Roadmap

## v0.2 delivered

- Discord-first branding and templates
- Public landing page
- User quotas
- Admin quota management
- Existing Python/Telegram/web app support retained
- systemd and Nginx deployment examples
- One-shot watchdog script

## v0.3 suggested

- Docker container per project
- Background task queue for requirements installation
- Real-time logs with SSE/WebSockets
- Admin project kill/restart controls
- Per-user plans and quotas UI
- Project resource usage metrics
- Built-in Discord bot health checks
- Template preview pages

## v0.4 suggested

- Reverse proxy automation
- Subdomains and custom domains
- SSL integration
- Web app port routing
- GitHub deploys
- Backup/restore UI
- Admin audit trail

## Production hosting version

- Container orchestration
- CPU/RAM/storage/network limits
- Abuse monitoring
- Malware scanning
- Billing integration, optional
- Multi-node worker architecture
