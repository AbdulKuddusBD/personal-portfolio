<?php
// Placeholder compatibility file: the MVP uses SQLite through Python. See database/schema.sql.
return ['driver' => 'sqlite'];
