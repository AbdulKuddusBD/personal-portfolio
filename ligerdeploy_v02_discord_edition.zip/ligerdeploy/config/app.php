<?php
// Placeholder compatibility file: the MVP uses Python/FastAPI. See .env.example for runtime configuration.
return ['name' => 'LigerDeploy'];
