(() => {
  const logWindow = document.querySelector('.log-window');
  if (logWindow) logWindow.scrollTop = logWindow.scrollHeight;
})();
