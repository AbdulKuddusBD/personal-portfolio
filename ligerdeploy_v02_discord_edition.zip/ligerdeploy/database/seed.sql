INSERT OR IGNORE INTO settings (key, value) VALUES ('panel_name', 'LigerDeploy');
INSERT OR IGNORE INTO settings (key, value) VALUES ('panel_version', '0.2.0-discord-edition');
INSERT OR IGNORE INTO settings (key, value) VALUES ('max_upload_mb', '50');
INSERT OR IGNORE INTO settings (key, value) VALUES ('default_user_max_projects', '3');
INSERT OR IGNORE INTO settings (key, value) VALUES ('default_user_max_storage_mb', '256');
INSERT OR IGNORE INTO settings (key, value) VALUES ('abuse_policy', 'No spam, unsolicited messaging, credential theft, scraping abuse, or platform ToS violations.');
