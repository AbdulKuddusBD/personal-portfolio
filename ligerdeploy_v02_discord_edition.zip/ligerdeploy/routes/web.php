<?php
// Placeholder compatibility file: routes are defined in app/controllers/*.py for the FastAPI MVP.
