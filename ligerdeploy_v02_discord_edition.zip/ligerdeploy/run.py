import os
import uvicorn

if __name__ == "__main__":
    host = os.environ.get("LIGERDEPLOY_HOST", "0.0.0.0")
    port = int(os.environ.get("LIGERDEPLOY_PORT", "8080"))
    reload = os.environ.get("LIGERDEPLOY_RELOAD", "true").lower() in {"1", "true", "yes", "on"}
    uvicorn.run("app.main:app", host=host, port=port, reload=reload)
