# LigerDeploy Security Notes

LigerDeploy v0.2 is an MVP. It is suitable as a starter project or private panel, not as a hardened multi-tenant public hosting platform without additional isolation.

## Implemented MVP protections

- Session authentication
- Admin/user roles
- CSRF token validation for forms
- Password hashing with PBKDF2
- Environment secret encryption when `ENV_SECRET_KEY` is configured
- Masked secrets in UI
- Project directory isolation by user/project path
- Path traversal protection
- Safe ZIP extraction with traversal checks
- Upload size limits
- Startup command allowlist
- Shell operators blocked
- Process runs with `shell=False`
- Logs stored per project

## Critical limitations

Uploaded Python code can execute arbitrary Python behavior inside the runtime account. A malicious user may attempt to read files, use network access, mine crypto, send spam, or attack local services if you do not isolate processes.

## Production requirements before public hosting

- Run projects in Docker or another sandbox
- Use a separate non-root Linux user or container per project
- Enforce CPU/RAM/PID/storage quotas
- Restrict network egress where possible
- Add malware/token-stealer scanning
- Add abuse reports and audit logs
- Add rate limits
- Add admin review for suspicious projects
- Keep panel dependencies updated
- Put the panel behind HTTPS

## Discord/Telegram abuse policy

Do not host spam, unsolicited messaging, mass DM bots, credential theft, token stealers, phishing, unauthorized scraping, selfbot abuse, or projects that violate Discord, Telegram, or other platform ToS.
