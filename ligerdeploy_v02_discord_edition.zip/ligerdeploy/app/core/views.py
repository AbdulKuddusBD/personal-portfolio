from fastapi.templating import Jinja2Templates
from app.core import config, csrf, auth


templates = Jinja2Templates(directory=str(config.VIEWS_PATH))


def context(request, **extra):
    user = auth.get_current_user(request)
    base = {
        "request": request,
        "app_name": config.APP_NAME,
        "app_version": config.APP_VERSION,
        "app_tagline": config.APP_TAGLINE,
        "current_user": user,
        "csrf_token": csrf.csrf_token(request),
        "allow_register": config.ALLOW_REGISTER,
        "project_type_labels": config.PROJECT_TYPE_LABELS,
        "project_type_descriptions": config.PROJECT_TYPE_DESCRIPTIONS,
        "startup_hints": config.STARTUP_HINTS,
    }
    base.update(extra)
    return base
