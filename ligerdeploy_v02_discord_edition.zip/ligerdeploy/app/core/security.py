import base64
import hashlib
import hmac
import os
from app.core import config

PBKDF2_ITERATIONS = 260_000


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        PBKDF2_ITERATIONS,
        base64.b64encode(salt).decode(),
        base64.b64encode(digest).decode(),
    )


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algorithm, iterations, salt_b64, digest_b64 = stored_hash.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def get_fernet():
    if not config.ENV_SECRET_KEY:
        return None
    try:
        from cryptography.fernet import Fernet
        return Fernet(config.ENV_SECRET_KEY.encode())
    except Exception:
        return None


def encrypt_secret(value: str) -> str:
    fernet = get_fernet()
    if fernet:
        return "fernet:" + fernet.encrypt(value.encode()).decode()
    # Fallback keeps the app usable if cryptography/key is missing, but production should use Fernet.
    return "base64:" + base64.b64encode(value.encode()).decode()


def decrypt_secret(value: str) -> str:
    if value.startswith("fernet:"):
        fernet = get_fernet()
        if not fernet:
            return ""
        return fernet.decrypt(value.removeprefix("fernet:").encode()).decode()
    if value.startswith("base64:"):
        return base64.b64decode(value.removeprefix("base64:")).decode()
    return value


def mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 4:
        return "****"
    return value[:2] + "****" + value[-2:]
