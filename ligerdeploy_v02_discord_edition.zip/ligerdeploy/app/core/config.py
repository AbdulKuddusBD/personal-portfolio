from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parents[2]
ENV_FILE = BASE_DIR / ".env"


def _load_env_file() -> None:
    if not ENV_FILE.exists():
        return
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


_load_env_file()


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def env_bool(name: str, default: bool = False) -> bool:
    value = env(name, str(default)).lower()
    return value in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    try:
        return int(env(name, str(default)))
    except ValueError:
        return default


APP_NAME = env("APP_NAME", "LigerDeploy")
APP_VERSION = env("APP_VERSION", "0.2.0")
APP_TAGLINE = env("APP_TAGLINE", "Host Discord bots, Telegram bots, Python workers, and web apps from one simple panel.")
APP_ENV = env("APP_ENV", "local")
APP_DEBUG = env_bool("APP_DEBUG", True)
APP_URL = env("APP_URL", "http://127.0.0.1:8080")
SECRET_KEY = env("SECRET_KEY", "dev-change-me")
ENV_SECRET_KEY = env("ENV_SECRET_KEY", "")
ALLOW_REGISTER = env_bool("ALLOW_REGISTER", True)
MAX_UPLOAD_MB = env_int("MAX_UPLOAD_MB", 50)
DEFAULT_USER_MAX_PROJECTS = env_int("DEFAULT_USER_MAX_PROJECTS", 3)
DEFAULT_USER_MAX_STORAGE_MB = env_int("DEFAULT_USER_MAX_STORAGE_MB", 256)
DEFAULT_USER_MAX_UPLOAD_MB = env_int("DEFAULT_USER_MAX_UPLOAD_MB", MAX_UPLOAD_MB)
PANEL_PYTHON_BIN = env("PANEL_PYTHON_BIN", "python3")

DATABASE_PATH = Path(env("DATABASE_PATH", "storage/database.sqlite"))
if not DATABASE_PATH.is_absolute():
    DATABASE_PATH = BASE_DIR / DATABASE_PATH

STORAGE_PATH = Path(env("STORAGE_PATH", "storage"))
if not STORAGE_PATH.is_absolute():
    STORAGE_PATH = BASE_DIR / STORAGE_PATH

PROJECTS_PATH = STORAGE_PATH / "projects"
LOGS_PATH = STORAGE_PATH / "logs"
PIDS_PATH = STORAGE_PATH / "pids"
UPLOADS_PATH = STORAGE_PATH / "uploads"
TEMPLATES_PATH = BASE_DIR / "templates"
VIEWS_PATH = BASE_DIR / "resources" / "views"
PUBLIC_PATH = BASE_DIR / "public"
ASSETS_PATH = PUBLIC_PATH / "assets"

ALLOWED_COMMANDS = {"python", "python3", "uvicorn", "gunicorn", "hypercorn", "daphne"}
FORBIDDEN_COMMAND_TOKENS = [";", "&&", "||", "|", ">", "<", "`", "$("]

PROJECT_TYPES = [
    "discord_bot",
    "telegram_bot",
    "userbot_mtproto",
    "fastapi_app",
    "flask_app",
    "django_app",
    "background_worker",
    "scheduler_app",
    "custom_python_script",
]

PROJECT_TYPE_LABELS = {
    "discord_bot": "Discord Bot",
    "telegram_bot": "Telegram Bot",
    "userbot_mtproto": "UserBot / MTProto App",
    "fastapi_app": "FastAPI App",
    "flask_app": "Flask App",
    "django_app": "Django App",
    "background_worker": "Background Worker",
    "scheduler_app": "Scheduler App",
    "custom_python_script": "Custom Python Script",
}

PROJECT_TYPE_DESCRIPTIONS = {
    "discord_bot": "discord.py, Pycord, Nextcord, Hikari or interaction-based Python Discord bots.",
    "telegram_bot": "Aiogram, python-telegram-bot, pyTelegramBotAPI and Telegram polling/webhook bots.",
    "userbot_mtproto": "Telethon, Pyrogram, Hydrogram and MTProto automation with abuse-prevention warnings.",
    "fastapi_app": "FastAPI, Starlette or aiohttp applications served through uvicorn/gunicorn.",
    "flask_app": "Flask applications served through python, gunicorn or another allowed runner.",
    "django_app": "Django apps prepared for gunicorn/ASGI future reverse proxy deployment.",
    "background_worker": "Long-running Python workers, Celery/RQ-style workers and automation processes.",
    "scheduler_app": "APScheduler or custom scheduled jobs that stay running in the background.",
    "custom_python_script": "Any allowed Python command that runs inside the isolated project directory.",
}

STARTUP_HINTS = {
    "discord_bot": "python bot.py",
    "telegram_bot": "python main.py",
    "userbot_mtproto": "python main.py",
    "fastapi_app": "uvicorn main:app --host 0.0.0.0 --port 8000",
    "flask_app": "python app.py",
    "django_app": "gunicorn myproject.wsgi:application --bind 0.0.0.0:8000",
    "background_worker": "python worker.py",
    "scheduler_app": "python main.py",
    "custom_python_script": "python main.py",
}
