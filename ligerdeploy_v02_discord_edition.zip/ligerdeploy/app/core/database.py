import sqlite3
from pathlib import Path
from typing import Any, Iterable
from app.core import config


def get_connection() -> sqlite3.Connection:
    config.DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(config.DATABASE_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    with get_connection() as conn:
        cur = conn.execute(sql, tuple(params))
        conn.commit()
        return int(cur.lastrowid or 0)


def execute_many(sql: str, rows: list[Iterable[Any]]) -> None:
    with get_connection() as conn:
        conn.executemany(sql, rows)
        conn.commit()


def query_one(sql: str, params: Iterable[Any] = ()) -> dict[str, Any] | None:
    with get_connection() as conn:
        cur = conn.execute(sql, tuple(params))
        row = cur.fetchone()
        return dict(row) if row else None


def query_all(sql: str, params: Iterable[Any] = ()) -> list[dict[str, Any]]:
    with get_connection() as conn:
        cur = conn.execute(sql, tuple(params))
        return [dict(row) for row in cur.fetchall()]


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def _migrate_existing(conn: sqlite3.Connection) -> None:
    user_cols = _columns(conn, "users")
    additions = {
        "max_projects": f"ALTER TABLE users ADD COLUMN max_projects INTEGER NOT NULL DEFAULT {config.DEFAULT_USER_MAX_PROJECTS}",
        "max_storage_mb": f"ALTER TABLE users ADD COLUMN max_storage_mb INTEGER NOT NULL DEFAULT {config.DEFAULT_USER_MAX_STORAGE_MB}",
        "max_upload_mb": f"ALTER TABLE users ADD COLUMN max_upload_mb INTEGER NOT NULL DEFAULT {config.DEFAULT_USER_MAX_UPLOAD_MB}",
    }
    for col, sql in additions.items():
        if col not in user_cols:
            conn.execute(sql)


def init_database() -> None:
    schema = Path(config.BASE_DIR / "database" / "schema.sql").read_text(encoding="utf-8")
    with get_connection() as conn:
        conn.executescript(schema)
        _migrate_existing(conn)
        conn.commit()
