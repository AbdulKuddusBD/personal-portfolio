from fastapi import Request
from starlette.responses import RedirectResponse
from app.core import database, security


def get_current_user(request: Request) -> dict | None:
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    return database.query_one("SELECT * FROM users WHERE id = ? AND is_active = 1", (user_id,))


def login(email: str, password: str) -> dict | None:
    user = database.query_one("SELECT * FROM users WHERE email = ? AND is_active = 1", (email.lower().strip(),))
    if not user or not security.verify_password(password, user["password_hash"]):
        return None
    return user


def login_user(request: Request, user: dict) -> None:
    request.session["user_id"] = user["id"]


def logout_user(request: Request) -> None:
    request.session.clear()


def redirect_to_login() -> RedirectResponse:
    return RedirectResponse(url="/login", status_code=303)


def redirect_to_dashboard() -> RedirectResponse:
    return RedirectResponse(url="/dashboard", status_code=303)


def is_admin(user: dict | None) -> bool:
    return bool(user and user.get("role") == "admin")
