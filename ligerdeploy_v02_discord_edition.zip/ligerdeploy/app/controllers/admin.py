import platform
from fastapi import APIRouter, Form, Request
from starlette.responses import RedirectResponse
from app.core import auth, csrf, database, config, security
from app.core.views import templates, context
from app.helpers.formatters import human_bytes
from app.services import project_service

router = APIRouter(prefix="/admin")


def admin_user(request: Request):
    user = auth.get_current_user(request)
    if not auth.is_admin(user):
        return None
    return user


@router.get("")
async def index(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    status = {
        "python": platform.python_version(),
        "database": str(config.DATABASE_PATH),
        "storage": str(config.STORAGE_PATH),
        "disk_usage": human_bytes(project_service.disk_usage(config.STORAGE_PATH)),
        "app_env": config.APP_ENV,
        "version": config.APP_VERSION,
    }
    return templates.TemplateResponse(request, "admin/system.html", context(request, status=status))


@router.get("/users")
async def users(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    rows = database.query_all("SELECT id, name, email, role, is_active, max_projects, max_storage_mb, max_upload_mb, created_at FROM users ORDER BY id DESC")
    return templates.TemplateResponse(request, "admin/users.html", context(request, users=rows))


@router.post("/users/create")
async def create_user(request: Request, name: str = Form(...), email: str = Form(...), password: str = Form(...), role: str = Form("user"), max_projects: int = Form(config.DEFAULT_USER_MAX_PROJECTS), max_storage_mb: int = Form(config.DEFAULT_USER_MAX_STORAGE_MB), max_upload_mb: int = Form(config.DEFAULT_USER_MAX_UPLOAD_MB), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    if role not in {"admin", "user"}:
        role = "user"
    database.execute(
        "INSERT INTO users (name, email, password_hash, role, is_active, max_projects, max_storage_mb, max_upload_mb) VALUES (?, ?, ?, ?, 1, ?, ?, ?)",
        (name.strip(), email.lower().strip(), security.hash_password(password), role, max_projects, max_storage_mb, max_upload_mb),
    )
    return RedirectResponse("/admin/users", status_code=303)


@router.post("/users/update-quota")
async def update_quota(request: Request, user_id: int = Form(...), max_projects: int = Form(...), max_storage_mb: int = Form(...), max_upload_mb: int = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    database.execute("UPDATE users SET max_projects = ?, max_storage_mb = ?, max_upload_mb = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (max_projects, max_storage_mb, max_upload_mb, user_id))
    return RedirectResponse("/admin/users", status_code=303)


@router.post("/users/toggle")
async def toggle_user(request: Request, user_id: int = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    if user_id != user["id"]:
        database.execute("UPDATE users SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?", (user_id,))
    return RedirectResponse("/admin/users", status_code=303)


@router.get("/projects")
async def projects(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    rows = database.query_all("SELECT projects.*, users.email AS user_email FROM projects JOIN users ON users.id = projects.user_id ORDER BY projects.id DESC")
    return templates.TemplateResponse(request, "admin/projects.html", context(request, projects=rows))


@router.get("/settings")
async def settings(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    rows = database.query_all("SELECT * FROM settings ORDER BY key")
    return templates.TemplateResponse(request, "admin/settings.html", context(request, settings=rows))


@router.post("/settings")
async def save_setting(request: Request, key: str = Form(...), value: str = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    database.execute("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP", (key.strip(), value.strip()))
    return RedirectResponse("/admin/settings", status_code=303)
