from fastapi import APIRouter, Request
from app.core import auth
from app.core.views import templates, context
from app.services import template_service

router = APIRouter(prefix="/templates")


@router.get("")
async def index(request: Request):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    rows = template_service.list_templates()
    return templates.TemplateResponse(request, "templates/index.html", context(request, templates=rows))
