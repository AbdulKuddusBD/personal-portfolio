from fastapi import APIRouter, Form, Request
from starlette.responses import RedirectResponse
from app.core import auth, csrf
from app.core.views import templates, context
from app.services import env_service, project_service

router = APIRouter(prefix="/projects/{project_id}/env")


@router.get("")
async def index(request: Request, project_id: int):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if not project:
        return RedirectResponse("/projects", status_code=303)
    vars_ = env_service.list_vars(project_id)
    return templates.TemplateResponse(request, "env/index.html", context(request, project=project, vars=vars_, error=None))


@router.post("/add")
async def add(request: Request, project_id: int, key: str = Form(...), value: str = Form(...), is_secret: str = Form("0"), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if project:
        env_service.add_var(project_id, key, value, is_secret == "1")
        env_service.write_dotenv(project)
    return RedirectResponse(f"/projects/{project_id}/env", status_code=303)


@router.post("/delete")
async def delete(request: Request, project_id: int, var_id: int = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if project:
        env_service.delete_var(var_id, project_id)
        env_service.write_dotenv(project)
    return RedirectResponse(f"/projects/{project_id}/env", status_code=303)
