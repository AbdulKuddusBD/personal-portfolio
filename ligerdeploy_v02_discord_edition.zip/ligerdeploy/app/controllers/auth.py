from fastapi import APIRouter, Form, Request
from starlette.responses import RedirectResponse
from app.core import auth, config, csrf, database, security
from app.core.views import templates, context
from app.services import activity_service

router = APIRouter()


@router.get("/")
async def home(request: Request):
    if auth.get_current_user(request):
        return RedirectResponse("/dashboard", status_code=303)
    return templates.TemplateResponse(request, "home.html", context(request))


@router.get("/login")
async def login_form(request: Request):
    return templates.TemplateResponse(request, "auth/login.html", context(request, error=None))


@router.post("/login")
async def login_post(request: Request, email: str = Form(...), password: str = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.login(email, password)
    if not user:
        return templates.TemplateResponse(request, "auth/login.html", context(request, error="Invalid email or password"), status_code=400)
    auth.login_user(request, user)
    activity_service.record(user["id"], None, "auth.login", "Logged in")
    return RedirectResponse("/dashboard", status_code=303)


@router.get("/register")
async def register_form(request: Request):
    if not config.ALLOW_REGISTER:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse(request, "auth/register.html", context(request, error=None))


@router.post("/register")
async def register_post(request: Request, name: str = Form(...), email: str = Form(...), password: str = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    if not config.ALLOW_REGISTER:
        return RedirectResponse("/login", status_code=303)
    email = email.lower().strip()
    if database.query_one("SELECT id FROM users WHERE email = ?", (email,)):
        return templates.TemplateResponse(request, "auth/register.html", context(request, error="Email already exists"), status_code=400)
    user_id = database.execute(
        """
        INSERT INTO users (name, email, password_hash, role, is_active, max_projects, max_storage_mb, max_upload_mb)
        VALUES (?, ?, ?, 'user', 1, ?, ?, ?)
        """,
        (name.strip(), email, security.hash_password(password), config.DEFAULT_USER_MAX_PROJECTS, config.DEFAULT_USER_MAX_STORAGE_MB, config.DEFAULT_USER_MAX_UPLOAD_MB),
    )
    user = database.query_one("SELECT * FROM users WHERE id = ?", (user_id,))
    auth.login_user(request, user)
    activity_service.record(user_id, None, "auth.register", "Registered account")
    return RedirectResponse("/dashboard", status_code=303)


@router.post("/logout")
async def logout(request: Request, csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    auth.logout_user(request)
    return RedirectResponse("/login", status_code=303)
