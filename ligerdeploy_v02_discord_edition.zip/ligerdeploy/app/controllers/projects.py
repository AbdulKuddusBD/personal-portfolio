from fastapi import APIRouter, Form, Request
from starlette.responses import RedirectResponse
from app.core import auth, config, csrf
from app.core.views import templates, context
from app.services import project_service, process_manager, template_service

router = APIRouter(prefix="/projects")


@router.get("")
async def index(request: Request):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    projects = project_service.list_projects(user)
    for project in projects:
        project["live_status"] = process_manager.refresh_status(project)
    return templates.TemplateResponse(request, "projects/list.html", context(request, projects=projects))


@router.get("/create")
async def create_form(request: Request, template: str = ""):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    selected_template = template_service.get_template(template) if template else None
    selected_type = selected_template["project_type"] if selected_template else "discord_bot"
    return templates.TemplateResponse(request, "projects/create.html", context(request, project_types=config.PROJECT_TYPES, template=template, selected_type=selected_type, selected_template=selected_template, error=None))


@router.post("/create")
async def create_post(request: Request, name: str = Form(...), project_type: str = Form(...), python_version: str = Form("3"), startup_command: str = Form(""), app_port: str = Form(""), template_slug: str = Form(""), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    try:
        project_id = project_service.create_project(user, name, project_type, python_version, startup_command, app_port, template_slug)
    except Exception as exc:
        selected_template = template_service.get_template(template_slug) if template_slug else None
        return templates.TemplateResponse(request, "projects/create.html", context(request, project_types=config.PROJECT_TYPES, template=template_slug, selected_type=project_type, selected_template=selected_template, error=str(exc)), status_code=400)
    return RedirectResponse(f"/projects/{project_id}", status_code=303)


@router.get("/{project_id}")
async def detail(request: Request, project_id: int):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if not project:
        return RedirectResponse("/projects", status_code=303)
    project["live_status"] = process_manager.refresh_status(project)
    return templates.TemplateResponse(request, "projects/detail.html", context(request, project=project))


@router.get("/{project_id}/edit")
async def edit_form(request: Request, project_id: int):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if not project:
        return RedirectResponse("/projects", status_code=303)
    return templates.TemplateResponse(request, "projects/edit.html", context(request, project=project, project_types=config.PROJECT_TYPES, error=None))


@router.post("/{project_id}/edit")
async def edit_post(request: Request, project_id: int, name: str = Form(...), project_type: str = Form(...), python_version: str = Form("3"), startup_command: str = Form(""), app_port: str = Form(""), webhook_url: str = Form(""), auto_restart: str = Form("0"), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project_service.update_project(project_id, user, name, project_type, python_version, startup_command, auto_restart == "1", app_port, webhook_url)
    return RedirectResponse(f"/projects/{project_id}", status_code=303)


@router.post("/{project_id}/delete")
async def delete_project(request: Request, project_id: int, csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if project:
        process_manager.stop_project(project, user)
        project_service.delete_project(project_id, user)
    return RedirectResponse("/projects", status_code=303)


@router.post("/{project_id}/install")
async def install(request: Request, project_id: int, csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if not project:
        return RedirectResponse("/projects", status_code=303)
    try:
        process_manager.install_requirements(project, user)
    except Exception as exc:
        project_service.set_status(project_id, "failed", installed=0)
        process_manager.log_file(project_id, "install.log").open("a", encoding="utf-8").write(f"\nERROR: {exc}\n")
    return RedirectResponse(f"/projects/{project_id}/logs?tab=install.log", status_code=303)


@router.post("/{project_id}/start")
async def start(request: Request, project_id: int, csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if project:
        try:
            process_manager.start_project(project, user)
        except Exception as exc:
            project_service.set_status(project_id, "failed")
            process_manager.log_file(project_id, "stderr.log").open("a", encoding="utf-8").write(f"\nSTART ERROR: {exc}\n")
    return RedirectResponse(f"/projects/{project_id}", status_code=303)


@router.post("/{project_id}/stop")
async def stop(request: Request, project_id: int, csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if project:
        process_manager.stop_project(project, user)
    return RedirectResponse(f"/projects/{project_id}", status_code=303)


@router.post("/{project_id}/restart")
async def restart(request: Request, project_id: int, csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if project:
        try:
            process_manager.restart_project(project, user)
        except Exception as exc:
            project_service.set_status(project_id, "failed")
            process_manager.log_file(project_id, "stderr.log").open("a", encoding="utf-8").write(f"\nRESTART ERROR: {exc}\n")
    return RedirectResponse(f"/projects/{project_id}", status_code=303)
