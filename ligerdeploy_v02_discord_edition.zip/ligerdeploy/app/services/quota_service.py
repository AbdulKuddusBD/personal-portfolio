from pathlib import Path
from app.core import config, database


def user_quota(user: dict) -> dict:
    if user.get("role") == "admin":
        return {"max_projects": 0, "max_storage_mb": 0, "max_upload_mb": config.MAX_UPLOAD_MB}
    return {
        "max_projects": int(user.get("max_projects") or config.DEFAULT_USER_MAX_PROJECTS),
        "max_storage_mb": int(user.get("max_storage_mb") or config.DEFAULT_USER_MAX_STORAGE_MB),
        "max_upload_mb": int(user.get("max_upload_mb") or config.DEFAULT_USER_MAX_UPLOAD_MB),
    }


def project_count(user_id: int) -> int:
    row = database.query_one("SELECT COUNT(*) AS count FROM projects WHERE user_id = ?", (user_id,))
    return int(row["count"] if row else 0)


def disk_usage(path: Path) -> int:
    total = 0
    if not path.exists():
        return 0
    for item in path.rglob("*"):
        try:
            if item.is_file():
                total += item.stat().st_size
        except OSError:
            pass
    return total


def user_disk_usage(user_id: int) -> int:
    return disk_usage(config.PROJECTS_PATH / str(user_id))


def enforce_create_project(user: dict) -> None:
    quota = user_quota(user)
    max_projects = quota["max_projects"]
    if max_projects > 0 and project_count(user["id"]) >= max_projects:
        raise ValueError(f"Project quota reached. Your plan allows {max_projects} project(s).")


def enforce_upload(user: dict, incoming_bytes: int) -> None:
    quota = user_quota(user)
    max_upload_mb = quota["max_upload_mb"] or config.MAX_UPLOAD_MB
    if incoming_bytes > max_upload_mb * 1024 * 1024:
        raise ValueError(f"Upload exceeds your per-file limit of {max_upload_mb} MB.")
    max_storage_mb = quota["max_storage_mb"]
    if max_storage_mb > 0 and user_disk_usage(user["id"]) + incoming_bytes > max_storage_mb * 1024 * 1024:
        raise ValueError(f"Storage quota reached. Your plan allows {max_storage_mb} MB.")
