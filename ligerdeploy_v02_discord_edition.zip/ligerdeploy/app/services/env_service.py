import re
from pathlib import Path
from app.core import database, security

KEY_RE = re.compile(r"^[A-Z_][A-Z0-9_]{1,80}$")
SECRET_HINTS = ("TOKEN", "SECRET", "PASSWORD", "PASS", "API_HASH", "SESSION", "KEY", "DATABASE_URL", "REDIS_URL", "MONGO_URL")


def validate_key(key: str) -> str:
    key = key.strip().upper()
    if not KEY_RE.match(key):
        raise ValueError("Environment variable keys must look like BOT_TOKEN or DATABASE_URL")
    return key


def is_secret_key(key: str) -> bool:
    key = key.upper()
    return any(part in key for part in SECRET_HINTS)


def list_vars(project_id: int, reveal: bool = False) -> list[dict]:
    rows = database.query_all("SELECT * FROM environment_variables WHERE project_id = ? ORDER BY key", (project_id,))
    result = []
    for row in rows:
        value = security.decrypt_secret(row["value_encrypted"])
        row["value"] = value if reveal else security.mask_secret(value)
        result.append(row)
    return result


def add_var(project_id: int, key: str, value: str, is_secret: bool | None = None) -> None:
    key = validate_key(key)
    secret = is_secret_key(key) if is_secret is None else is_secret
    encrypted = security.encrypt_secret(value.strip())
    database.execute(
        """
        INSERT INTO environment_variables (project_id, key, value_encrypted, is_secret)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(project_id, key) DO UPDATE SET value_encrypted = excluded.value_encrypted, is_secret = excluded.is_secret, updated_at = CURRENT_TIMESTAMP
        """,
        (project_id, key, encrypted, 1 if secret else 0),
    )


def delete_var(var_id: int, project_id: int) -> None:
    database.execute("DELETE FROM environment_variables WHERE id = ? AND project_id = ?", (var_id, project_id))


def runtime_env(project_id: int) -> dict[str, str]:
    return {row["key"]: security.decrypt_secret(row["value_encrypted"]) for row in database.query_all("SELECT * FROM environment_variables WHERE project_id = ?", (project_id,))}


def write_dotenv(project: dict) -> None:
    root = Path(project["project_path"])
    root.mkdir(parents=True, exist_ok=True)
    lines = []
    for key, value in runtime_env(project["id"]).items():
        escaped = value.replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')
        lines.append(f'{key}="{escaped}"')
    (root / ".env").write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
