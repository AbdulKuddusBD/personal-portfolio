import shutil
from pathlib import Path
from app.core import config

TEMPLATE_META = {
    "discordpy-basic-bot": ("Discord Bot", "discord_bot", "discord.py starter with slash command, prefix command, BOT_TOKEN, and safe intents."),
    "pycord-basic-bot": ("Discord Bot", "discord_bot", "Pycord starter with slash command support and BOT_TOKEN environment variable."),
    "nextcord-basic-bot": ("Discord Bot", "discord_bot", "Nextcord starter for Python Discord bots."),
    "hikari-lightbulb-bot": ("Discord Bot", "discord_bot", "Hikari + Lightbulb Discord bot starter."),
    "aiogram-basic-bot": ("Telegram Bot", "telegram_bot", "Aiogram polling bot with BOT_TOKEN."),
    "aiogram-fastapi-webhook": ("Telegram Bot", "telegram_bot", "Aiogram + FastAPI webhook-ready starter."),
    "fastapi-basic-api": ("FastAPI App", "fastapi_app", "Simple API served by uvicorn."),
    "flask-basic-app": ("Flask App", "flask_app", "Minimal Flask app."),
    "django-basic-app": ("Django App", "django_app", "Minimal Django project layout."),
    "telethon-userbot": ("UserBot / MTProto App", "userbot_mtproto", "Telethon session-string userbot skeleton with ToS warning."),
    "pyrogram-userbot": ("UserBot / MTProto App", "userbot_mtproto", "Pyrogram userbot skeleton with ToS warning."),
    "apscheduler-worker": ("Scheduler App", "scheduler_app", "APScheduler background worker."),
}


def list_templates() -> list[dict]:
    rows = []
    if not config.TEMPLATES_PATH.exists():
        return rows
    for path in sorted(config.TEMPLATES_PATH.iterdir()):
        if path.is_dir():
            title, project_type, description = TEMPLATE_META.get(path.name, (path.name, "custom_python_script", "Starter template"))
            rows.append({"slug": path.name, "title": title, "project_type": project_type, "description": description, "path": path})
    return rows


def get_template(slug: str) -> dict | None:
    for item in list_templates():
        if item["slug"] == slug:
            return item
    return None


def copy_template(slug: str, destination: Path) -> None:
    source = (config.TEMPLATES_PATH / slug).resolve()
    if not source.exists() or config.TEMPLATES_PATH.resolve() not in source.parents:
        raise ValueError("Template not found")
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)
