import os
import re
import shutil
from pathlib import Path
from app.core import config, database
from app.services import activity_service, quota_service

SLUG_RE = re.compile(r"[^a-z0-9-]+")


def slugify(value: str) -> str:
    value = value.lower().strip().replace("_", "-").replace(" ", "-")
    value = SLUG_RE.sub("", value)
    value = re.sub(r"-+", "-", value).strip("-")
    return value or "project"


def unique_slug(user_id: int, name: str) -> str:
    base = slugify(name)
    slug = base
    counter = 2
    while database.query_one("SELECT id FROM projects WHERE user_id = ? AND slug = ?", (user_id, slug)):
        slug = f"{base}-{counter}"
        counter += 1
    return slug


def project_dir(user_id: int, slug: str) -> Path:
    return config.PROJECTS_PATH / str(user_id) / slug


def ensure_project_dirs(project: dict) -> None:
    root = Path(project["project_path"])
    root.mkdir(parents=True, exist_ok=True)
    (config.LOGS_PATH / str(project["id"])).mkdir(parents=True, exist_ok=True)
    config.PIDS_PATH.mkdir(parents=True, exist_ok=True)


def create_project(user: dict, name: str, project_type: str, python_version: str = "3", startup_command: str = "", app_port: str = "", template_slug: str = "") -> int:
    quota_service.enforce_create_project(user)
    if project_type not in config.PROJECT_TYPES:
        project_type = "discord_bot"
    startup_command = (startup_command or "").strip() or config.STARTUP_HINTS.get(project_type, "python main.py")
    slug = unique_slug(user["id"], name)
    path = project_dir(user["id"], slug)
    project_id = database.execute(
        """
        INSERT INTO projects (user_id, name, slug, project_type, python_version, project_path, startup_command, app_port, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'created')
        """,
        (user["id"], name.strip(), slug, project_type, python_version.strip() or "3", str(path), startup_command, app_port.strip()),
    )
    project = get_project(project_id, user)
    ensure_project_dirs(project)
    if template_slug:
        from app.services import template_service
        template_service.copy_template(template_slug, Path(project["project_path"]))
    activity_service.record(user["id"], project_id, "project.created", f"Created {config.PROJECT_TYPE_LABELS.get(project_type, project_type)} project {name}")
    return project_id


def update_project(project_id: int, user: dict, name: str, project_type: str, python_version: str, startup_command: str, auto_restart: bool, app_port: str = "", webhook_url: str = "") -> None:
    project = get_project(project_id, user)
    if not project:
        return
    if project_type not in config.PROJECT_TYPES:
        project_type = project["project_type"]
    database.execute(
        """
        UPDATE projects
        SET name = ?, project_type = ?, python_version = ?, startup_command = ?, auto_restart = ?, app_port = ?, webhook_url = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (name.strip(), project_type, python_version.strip() or "3", startup_command.strip(), 1 if auto_restart else 0, app_port.strip(), webhook_url.strip(), project_id),
    )
    activity_service.record(user["id"], project_id, "project.updated", f"Updated project {name}")


def delete_project(project_id: int, user: dict) -> None:
    project = get_project(project_id, user)
    if not project:
        return
    root = Path(project["project_path"])
    if root.exists():
        shutil.rmtree(root)
    log_dir = config.LOGS_PATH / str(project_id)
    if log_dir.exists():
        shutil.rmtree(log_dir)
    pid = config.PIDS_PATH / f"{project_id}.pid"
    if pid.exists():
        pid.unlink()
    activity_service.record(user["id"], project_id, "project.deleted", f"Deleted project {project['name']}")
    database.execute("DELETE FROM projects WHERE id = ?", (project_id,))


def list_projects(user: dict) -> list[dict]:
    if user["role"] == "admin":
        return database.query_all(
            """
            SELECT projects.*, users.email AS user_email
            FROM projects JOIN users ON users.id = projects.user_id
            ORDER BY projects.id DESC
            """
        )
    return database.query_all("SELECT * FROM projects WHERE user_id = ? ORDER BY id DESC", (user["id"],))


def get_project(project_id: int, user: dict | None = None) -> dict | None:
    project = database.query_one("SELECT * FROM projects WHERE id = ?", (project_id,))
    if not project:
        return None
    if user and user.get("role") != "admin" and project["user_id"] != user["id"]:
        return None
    return project


def get_project_unrestricted(project_id: int) -> dict | None:
    return database.query_one("SELECT * FROM projects WHERE id = ?", (project_id,))


def counts(user: dict) -> dict:
    if user["role"] == "admin":
        rows = database.query_all("SELECT status, COUNT(*) AS count FROM projects GROUP BY status")
    else:
        rows = database.query_all("SELECT status, COUNT(*) AS count FROM projects WHERE user_id = ? GROUP BY status", (user["id"],))
    data = {row["status"]: row["count"] for row in rows}
    total = sum(data.values())
    return {
        "total": total,
        "running": data.get("running", 0),
        "stopped": data.get("stopped", 0),
        "failed": data.get("failed", 0) + data.get("crashed", 0),
        "created": data.get("created", 0),
    }


def disk_usage(path: Path) -> int:
    total = 0
    if not path.exists():
        return total
    for dirpath, _, filenames in os.walk(path):
        for filename in filenames:
            try:
                total += (Path(dirpath) / filename).stat().st_size
            except OSError:
                pass
    return total


def user_disk_usage(user: dict) -> int:
    if user["role"] == "admin":
        return disk_usage(config.STORAGE_PATH)
    return disk_usage(config.PROJECTS_PATH / str(user["id"]))


def set_status(project_id: int, status: str, installed: int | None = None) -> None:
    if installed is None:
        database.execute("UPDATE projects SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (status, project_id))
    else:
        database.execute("UPDATE projects SET status = ?, installed = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (status, installed, project_id))
