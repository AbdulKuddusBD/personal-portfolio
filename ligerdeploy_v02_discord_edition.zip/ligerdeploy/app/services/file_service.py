import os
import shutil
import zipfile
from pathlib import Path
from app.core import config

TEXT_EXTENSIONS = {".py", ".txt", ".md", ".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".env", ".html", ".css", ".js", ".sql"}


def safe_join(base: Path, relative: str | None = "") -> Path:
    base = base.resolve()
    relative = (relative or "").strip().lstrip("/")
    target = (base / relative).resolve()
    if target != base and base not in target.parents:
        raise ValueError("Path traversal attempt blocked")
    return target


def rel_path(base: Path, target: Path) -> str:
    return str(target.resolve().relative_to(base.resolve())).replace("\\", "/")


def list_dir(project: dict, relative: str = "") -> dict:
    base = Path(project["project_path"])
    current = safe_join(base, relative)
    current.mkdir(parents=True, exist_ok=True)
    if not current.is_dir():
        raise ValueError("Not a directory")
    entries = []
    for child in sorted(current.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        entries.append({
            "name": child.name,
            "path": rel_path(base, child),
            "is_dir": child.is_dir(),
            "size": child.stat().st_size if child.is_file() else 0,
            "suffix": child.suffix.lower(),
        })
    parent = ""
    if current != base:
        parent = rel_path(base, current.parent)
    return {"current": rel_path(base, current) if current != base else "", "parent": parent, "entries": entries}


def save_upload(project: dict, relative: str, filename: str, content: bytes) -> str:
    if len(content) > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise ValueError("Upload exceeds configured size limit")
    safe_name = Path(filename).name
    if not safe_name or safe_name in {".", ".."}:
        raise ValueError("Invalid filename")
    target_dir = safe_join(Path(project["project_path"]), relative)
    target_dir.mkdir(parents=True, exist_ok=True)
    target = safe_join(target_dir, safe_name)
    target.write_bytes(content)
    return rel_path(Path(project["project_path"]), target)


def create_file(project: dict, relative: str, name: str) -> None:
    target = safe_join(safe_join(Path(project["project_path"]), relative), Path(name).name)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.touch(exist_ok=False)


def create_folder(project: dict, relative: str, name: str) -> None:
    target = safe_join(safe_join(Path(project["project_path"]), relative), Path(name).name)
    target.mkdir(parents=True, exist_ok=False)


def delete_path(project: dict, relative: str) -> None:
    target = safe_join(Path(project["project_path"]), relative)
    if target == Path(project["project_path"]).resolve():
        raise ValueError("Cannot delete project root")
    if target.is_dir():
        shutil.rmtree(target)
    elif target.exists():
        target.unlink()


def rename_path(project: dict, relative: str, new_name: str) -> str:
    target = safe_join(Path(project["project_path"]), relative)
    if target == Path(project["project_path"]).resolve():
        raise ValueError("Cannot rename project root")
    destination = safe_join(target.parent, Path(new_name).name)
    target.rename(destination)
    return rel_path(Path(project["project_path"]), destination)


def is_text_file(path: Path) -> bool:
    if path.suffix.lower() in TEXT_EXTENSIONS:
        return True
    if path.stat().st_size > 1024 * 1024:
        return False
    try:
        data = path.read_bytes()[:2048]
        return b"\x00" not in data
    except Exception:
        return False


def read_text(project: dict, relative: str) -> str:
    target = safe_join(Path(project["project_path"]), relative)
    if not target.is_file() or not is_text_file(target):
        raise ValueError("File is not editable text")
    return target.read_text(encoding="utf-8", errors="replace")


def write_text(project: dict, relative: str, content: str) -> None:
    target = safe_join(Path(project["project_path"]), relative)
    if not target.is_file() or not is_text_file(target):
        raise ValueError("File is not editable text")
    target.write_text(content, encoding="utf-8")


def extract_zip(project: dict, zip_relative: str) -> list[str]:
    base = Path(project["project_path"])
    zip_path = safe_join(base, zip_relative)
    if zip_path.suffix.lower() != ".zip" or not zip_path.is_file():
        raise ValueError("Only ZIP files can be extracted")
    extracted = []
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError(f"Unsafe ZIP entry blocked: {name}")
            destination = safe_join(base, name)
            if info.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, destination.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            extracted.append(rel_path(base, destination))
    return extracted


def make_backup(project: dict) -> Path:
    base = Path(project["project_path"])
    backup_dir = config.UPLOADS_PATH / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup_path = backup_dir / f"{project['slug']}-backup.zip"
    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, _, filenames in os.walk(base):
            for filename in filenames:
                full = Path(dirpath) / filename
                zf.write(full, full.relative_to(base))
    return backup_path
