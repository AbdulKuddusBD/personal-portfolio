from app.core import database


def record(user_id: int | None, project_id: int | None, action: str, message: str) -> None:
    database.execute(
        "INSERT INTO activity_logs (user_id, project_id, action, message) VALUES (?, ?, ?, ?)",
        (user_id, project_id, action, message),
    )


def recent(user_id: int | None = None, limit: int = 10) -> list[dict]:
    if user_id:
        return database.query_all(
            """
            SELECT activity_logs.*, projects.name AS project_name
            FROM activity_logs
            LEFT JOIN projects ON projects.id = activity_logs.project_id
            WHERE activity_logs.user_id = ?
            ORDER BY activity_logs.id DESC LIMIT ?
            """,
            (user_id, limit),
        )
    return database.query_all(
        """
        SELECT activity_logs.*, projects.name AS project_name, users.email AS user_email
        FROM activity_logs
        LEFT JOIN projects ON projects.id = activity_logs.project_id
        LEFT JOIN users ON users.id = activity_logs.user_id
        ORDER BY activity_logs.id DESC LIMIT ?
        """,
        (limit,),
    )
