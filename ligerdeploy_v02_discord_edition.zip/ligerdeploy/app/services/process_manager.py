import os
import shlex
import signal
import subprocess
import sys
from pathlib import Path
from app.core import config
from app.services import env_service, project_service, activity_service


def pid_file(project_id: int) -> Path:
    config.PIDS_PATH.mkdir(parents=True, exist_ok=True)
    return config.PIDS_PATH / f"{project_id}.pid"


def log_dir(project_id: int) -> Path:
    path = config.LOGS_PATH / str(project_id)
    path.mkdir(parents=True, exist_ok=True)
    return path


def log_file(project_id: int, name: str) -> Path:
    return log_dir(project_id) / name


def is_pid_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except OSError:
        return False


def running_pid(project_id: int) -> int | None:
    pf = pid_file(project_id)
    if not pf.exists():
        return None
    try:
        pid = int(pf.read_text().strip())
    except ValueError:
        pf.unlink(missing_ok=True)
        return None
    if is_pid_running(pid):
        return pid
    pf.unlink(missing_ok=True)
    return None


def validate_startup_command(command: str) -> list[str]:
    command = (command or "").strip()
    if not command:
        raise ValueError("Startup command is required")
    for token in config.FORBIDDEN_COMMAND_TOKENS:
        if token in command:
            raise ValueError(f"Shell operator '{token}' is not allowed")
    parts = shlex.split(command)
    if not parts:
        raise ValueError("Startup command is empty")
    executable = Path(parts[0]).name
    if executable not in config.ALLOWED_COMMANDS:
        raise ValueError("Command must start with python, uvicorn, gunicorn, hypercorn, or daphne")
    return parts


def _venv_executable(project_root: Path, executable: str) -> str:
    if os.name == "nt":
        candidates = [project_root / ".venv" / "Scripts" / executable, project_root / ".venv" / "Scripts" / f"{executable}.exe"]
    else:
        candidates = [project_root / ".venv" / "bin" / executable]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return executable


def _runtime_args(project_root: Path, args: list[str]) -> list[str]:
    args = args.copy()
    exe = Path(args[0]).name
    if exe in {"python", "python3"}:
        args[0] = _venv_executable(project_root, "python")
    else:
        args[0] = _venv_executable(project_root, exe)
    return args


def install_requirements(project: dict, user: dict | None = None) -> None:
    root = Path(project["project_path"])
    requirements = root / "requirements.txt"
    install_log = log_file(project["id"], "install.log")
    if not requirements.exists():
        raise ValueError("requirements.txt was not found in the project root")
    project_service.set_status(project["id"], "installing")
    with install_log.open("ab") as log:
        log.write(b"\n==== Creating virtual environment ====\n")
        subprocess.run([config.PANEL_PYTHON_BIN, "-m", "venv", str(root / ".venv")], cwd=str(root), stdout=log, stderr=subprocess.STDOUT, check=True)
        pip = _venv_executable(root, "pip")
        log.write(b"\n==== Upgrading pip ====\n")
        subprocess.run([pip, "install", "--upgrade", "pip"], cwd=str(root), stdout=log, stderr=subprocess.STDOUT, check=True)
        log.write(b"\n==== Installing requirements.txt ====\n")
        subprocess.run([pip, "install", "-r", str(requirements)], cwd=str(root), stdout=log, stderr=subprocess.STDOUT, check=True)
    project_service.set_status(project["id"], "stopped", installed=1)
    if user:
        activity_service.record(user["id"], project["id"], "requirements.installed", "Installed requirements.txt")


def start_project(project: dict, user: dict | None = None) -> None:
    if running_pid(project["id"]):
        return
    root = Path(project["project_path"])
    args = validate_startup_command(project.get("startup_command") or "")
    args = _runtime_args(root, args)
    env_service.write_dotenv(project)
    env = os.environ.copy()
    env.update(env_service.runtime_env(project["id"]))
    stdout_path = log_file(project["id"], "stdout.log")
    stderr_path = log_file(project["id"], "stderr.log")
    stdout = stdout_path.open("ab", buffering=0)
    stderr = stderr_path.open("ab", buffering=0)
    kwargs = {"cwd": str(root), "env": env, "stdout": stdout, "stderr": stderr, "shell": False}
    if os.name != "nt":
        kwargs["preexec_fn"] = os.setsid
    process = subprocess.Popen(args, **kwargs)
    stdout.close()
    stderr.close()
    pid_file(project["id"]).write_text(str(process.pid), encoding="utf-8")
    project_service.set_status(project["id"], "running")
    if user:
        activity_service.record(user["id"], project["id"], "project.started", f"Started with PID {process.pid}")


def stop_project(project: dict, user: dict | None = None) -> None:
    pid = running_pid(project["id"])
    if pid:
        try:
            if os.name != "nt":
                os.killpg(os.getpgid(pid), signal.SIGTERM)
            else:
                os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    pid_file(project["id"]).unlink(missing_ok=True)
    project_service.set_status(project["id"], "stopped")
    if user:
        activity_service.record(user["id"], project["id"], "project.stopped", "Stopped project")


def restart_project(project: dict, user: dict | None = None) -> None:
    stop_project(project, user)
    start_project(project, user)
    if user:
        activity_service.record(user["id"], project["id"], "project.restarted", "Restarted project")


def refresh_status(project: dict) -> str:
    pid = running_pid(project["id"])
    if pid:
        if project["status"] != "running":
            project_service.set_status(project["id"], "running")
        return "running"
    if project["status"] == "running":
        project_service.set_status(project["id"], "crashed")
        return "crashed"
    return project["status"]


def tail(project_id: int, name: str, max_bytes: int = 8000) -> str:
    path = log_file(project_id, name)
    if not path.exists():
        return ""
    with path.open("rb") as fh:
        try:
            fh.seek(-max_bytes, os.SEEK_END)
        except OSError:
            fh.seek(0)
        return fh.read().decode("utf-8", errors="replace")


def clear_log(project_id: int, name: str) -> None:
    log_file(project_id, name).write_text("", encoding="utf-8")
