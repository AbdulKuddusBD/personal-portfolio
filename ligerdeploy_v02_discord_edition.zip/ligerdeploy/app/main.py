from fastapi import FastAPI
from starlette.middleware.sessions import SessionMiddleware
from starlette.staticfiles import StaticFiles
from app.core import config
from app.core.database import init_database
from app.controllers import admin, auth, dashboard, env, files, logs, projects, templates


def create_app() -> FastAPI:
    app = FastAPI(title="LigerDeploy", debug=config.APP_DEBUG)
    app.add_middleware(SessionMiddleware, secret_key=config.SECRET_KEY, same_site="lax", https_only=False)
    app.mount("/assets", StaticFiles(directory=str(config.ASSETS_PATH)), name="assets")
    init_database()
    for path in [config.PROJECTS_PATH, config.LOGS_PATH, config.PIDS_PATH, config.UPLOADS_PATH]:
        path.mkdir(parents=True, exist_ok=True)
    app.include_router(auth.router)
    app.include_router(dashboard.router)
    app.include_router(projects.router)
    app.include_router(files.router)
    app.include_router(env.router)
    app.include_router(logs.router)
    app.include_router(templates.router)
    app.include_router(admin.router)
    return app


app = create_app()
