from datetime import datetime


def human_bytes(size: int | float | None) -> str:
    size = float(size or 0)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def status_badge(status: str) -> str:
    return {
        "running": "success",
        "stopped": "secondary",
        "created": "info",
        "installing": "warning",
        "crashed": "danger",
        "failed": "danger",
    }.get(status, "secondary")


def now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
