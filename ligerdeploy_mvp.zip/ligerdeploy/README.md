# LigerDeploy MVP

LigerDeploy is a self-hosted Python app hosting panel for developers who run Telegram bots, UserBots/MTProto apps, FastAPI apps, Flask/Django apps, workers, schedulers, and custom Python scripts.

**Tagline:** Deploy Telegram Bots, UserBots, FastAPI apps, Python workers, and scripts from one simple panel.

## MVP features

- Admin and user login with session authentication and PBKDF2 password hashing.
- Role system: `admin` and `user`.
- Project dashboard with status counts, disk usage, recent activity, and project list.
- Project manager: create, edit, delete, start, stop, restart, install requirements, manage files, manage env vars, and view logs.
- Browser file manager: upload files, upload ZIPs, extract ZIPs safely, create files/folders, rename, delete, edit text files, download files, and create ZIP backups.
- Per-project virtual environment using `python -m venv .venv`.
- Requirements installer with saved `install.log`.
- Environment variable manager with masked secrets and encrypted values when `cryptography`/Fernet key is available.
- Startup command validation with allowlist: `python`, `python3`, `uvicorn`, `gunicorn`, `hypercorn`, `daphne`.
- Local PID-file process manager with stdout/stderr/install logs.
- Starter templates for Telegram bots, UserBots, FastAPI, Flask, Django, and APScheduler workers.

## Requirements

- Python 3.10+
- SQLite
- Linux/macOS recommended for process-group stop support. Windows works for basic development.

## Installation

```bash
cd ligerdeploy
python3 -m venv .panel-venv
source .panel-venv/bin/activate
pip install -r requirements.txt
python scripts/install.py
python run.py
```

Open:

```text
http://127.0.0.1:8080
```

The installer creates `.env`, initializes SQLite, creates storage directories, and asks for an admin account. If you press Enter at prompts, it creates `admin@example.com` with password `admin12345`; change it immediately.

## Main workflow

1. Login.
2. Create a project.
3. Choose a project type such as Telegram Bot, UserBot / MTProto App, FastAPI App, Flask App, Django App, Background Worker, Scheduler App, or Custom Python Script.
4. Upload a ZIP or individual files from the file manager.
5. Extract ZIP files from the file manager.
6. Check that `requirements.txt` exists in the project root.
7. Click **Install Requirements**.
8. Add environment variables such as `BOT_TOKEN`, `API_ID`, `API_HASH`, `SESSION_STRING`, `DATABASE_URL`, `REDIS_URL`, `MONGO_URL`, or `SECRET_KEY`.
9. Set a startup command.
10. Start the project and view live logs.

## Example startup commands

```bash
python main.py
python bot.py
uvicorn main:app --host 0.0.0.0 --port 8000
gunicorn myproject.wsgi:application --bind 0.0.0.0:8000
python userbot.py
```

Shell operators are blocked. The command must begin with an allowlisted runtime and runs inside the project directory.

## Logs

Each project has:

```text
storage/logs/{project_id}/stdout.log
storage/logs/{project_id}/stderr.log
storage/logs/{project_id}/install.log
```

The MVP uses periodic refresh through the browser. The code structure leaves room for WebSocket/SSE streaming later.

## Storage layout

```text
storage/projects/{user_id}/{project_slug}/
storage/logs/{project_id}/stdout.log
storage/logs/{project_id}/stderr.log
storage/logs/{project_id}/install.log
storage/pids/{project_id}.pid
```

## Security warning

This MVP can execute uploaded Python code. Use it only in a trusted local or private environment until container isolation is added. For production, use Docker/container isolation per project, per-user Linux users, CPU/RAM/storage limits, reverse proxy isolation, rate limiting, audit logging, and malware scanning.

## Telegram and UserBot policy note

LigerDeploy is intended for legitimate automation and bot hosting. Do not use it for spam, unsolicited messaging, credential theft, scraping abuse, account farming, or activity that violates Telegram Terms of Service or local law.

## Production notes

- Run the panel as a non-root user.
- Put the panel behind Nginx/Caddy with HTTPS.
- Disable open registration if not needed.
- Replace the local process manager with Docker, Supervisor, or systemd.
- Add resource limits and abuse monitoring.
- Keep `.env`, SQLite database, logs, and project files out of public web roots.

## Development commands

```bash
python scripts/doctor.py
python run.py
```
