# LigerDeploy Security Notes

LigerDeploy's core risk is intentional: users upload and run Python code. The MVP includes guardrails, but it is not a complete production sandbox.

## Implemented in MVP

- Session-based authentication.
- PBKDF2 password hashing.
- Admin/user roles.
- CSRF tokens for form POST actions.
- Path traversal protection for file operations.
- Project directory isolation by user ID and project slug.
- Safe ZIP extraction that blocks absolute paths and `..` path traversal.
- Startup command allowlist.
- Shell operators blocked in startup commands.
- `subprocess.Popen(..., shell=False)` for runtime execution.
- Per-project PID and log files.
- Environment values masked in UI.
- Environment values encrypted through Fernet when `ENV_SECRET_KEY` is configured.

## Still required for production

- Run each project inside a Docker container or other sandbox.
- Run app processes as non-root with separate users or containers.
- Enforce CPU, memory, process, network, and storage limits.
- Add outbound network rules where needed.
- Add malware scanning for uploads.
- Add audit logging and abuse monitoring.
- Add rate limiting and account verification.
- Add secure reverse proxy for web apps.
- Rotate secrets and backup the database securely.
- Protect `storage/`, `.env`, and SQLite files from public access.

## Telegram abuse prevention

Do not use LigerDeploy to host spam bots, unsolicited messaging systems, credential theft tools, unauthorized scrapers, account automation that violates service terms, or other abusive automation.
