# LigerDeploy Roadmap

## Near-term hardening

- Add async/background install tasks so large `pip install` operations do not block requests.
- Add SSE or WebSocket log streaming.
- Add project health checks and auto-restart watchdog.
- Add per-project resource usage metrics.
- Add better code editor with syntax highlighting.
- Add upload quotas per user.

## Production runtime

- Docker container per project.
- CPU/RAM/storage limits.
- Per-project network controls.
- Supervisor/systemd integration alternative.
- Dedicated runtime user per project.
- Runtime image selection by Python version.

## Web app hosting

- Reverse proxy integration with Nginx or Caddy.
- Subdomain routing.
- Custom domains.
- Automatic SSL.
- Port allocation and conflict detection.

## Telegram features

- Bot webhook setup/delete/test.
- Webhook URL manager.
- Telegram Bot API status checker.
- Webhook logs.
- Safer UserBot session handling.

## Admin and compliance

- Audit logs.
- Abuse reporting.
- Rate limits.
- Malware scanning.
- User quotas and storage policies.
- Backup/restore tools.

## Database options

- PostgreSQL and MySQL support via repository layer.
- Migration runner.
- Admin backup and export UI.
