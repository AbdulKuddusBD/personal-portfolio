INSERT OR IGNORE INTO settings (key, value) VALUES ('panel_name', 'LigerDeploy');
INSERT OR IGNORE INTO settings (key, value) VALUES ('max_upload_mb', '50');
