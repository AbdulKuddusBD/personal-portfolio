from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parents[2]
ENV_FILE = BASE_DIR / ".env"


def _load_env_file() -> None:
    if not ENV_FILE.exists():
        return
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


_load_env_file()


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def env_bool(name: str, default: bool = False) -> bool:
    value = env(name, str(default)).lower()
    return value in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    try:
        return int(env(name, str(default)))
    except ValueError:
        return default


APP_NAME = env("APP_NAME", "LigerDeploy")
APP_ENV = env("APP_ENV", "local")
APP_DEBUG = env_bool("APP_DEBUG", True)
APP_URL = env("APP_URL", "http://127.0.0.1:8080")
SECRET_KEY = env("SECRET_KEY", "dev-change-me")
ENV_SECRET_KEY = env("ENV_SECRET_KEY", "")
ALLOW_REGISTER = env_bool("ALLOW_REGISTER", True)
MAX_UPLOAD_MB = env_int("MAX_UPLOAD_MB", 50)
PANEL_PYTHON_BIN = env("PANEL_PYTHON_BIN", "python3")

DATABASE_PATH = Path(env("DATABASE_PATH", "storage/database.sqlite"))
if not DATABASE_PATH.is_absolute():
    DATABASE_PATH = BASE_DIR / DATABASE_PATH

STORAGE_PATH = Path(env("STORAGE_PATH", "storage"))
if not STORAGE_PATH.is_absolute():
    STORAGE_PATH = BASE_DIR / STORAGE_PATH

PROJECTS_PATH = STORAGE_PATH / "projects"
LOGS_PATH = STORAGE_PATH / "logs"
PIDS_PATH = STORAGE_PATH / "pids"
UPLOADS_PATH = STORAGE_PATH / "uploads"
TEMPLATES_PATH = BASE_DIR / "templates"
VIEWS_PATH = BASE_DIR / "resources" / "views"
PUBLIC_PATH = BASE_DIR / "public"
ASSETS_PATH = PUBLIC_PATH / "assets"

ALLOWED_COMMANDS = {"python", "python3", "uvicorn", "gunicorn", "hypercorn", "daphne"}
FORBIDDEN_COMMAND_TOKENS = [";", "&&", "||", "|", ">", "<", "`", "$("]
PROJECT_TYPES = [
    "telegram_bot",
    "userbot_mtproto",
    "fastapi_app",
    "flask_app",
    "django_app",
    "background_worker",
    "scheduler_app",
    "custom_python_script",
]
