from fastapi.templating import Jinja2Templates
from app.core import config, csrf, auth


templates = Jinja2Templates(directory=str(config.VIEWS_PATH))


def context(request, **extra):
    user = auth.get_current_user(request)
    base = {
        "request": request,
        "app_name": config.APP_NAME,
        "current_user": user,
        "csrf_token": csrf.csrf_token(request),
        "allow_register": config.ALLOW_REGISTER,
    }
    base.update(extra)
    return base
