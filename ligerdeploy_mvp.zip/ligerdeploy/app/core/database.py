import sqlite3
from pathlib import Path
from typing import Any, Iterable
from app.core import config


def get_connection() -> sqlite3.Connection:
    config.DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(config.DATABASE_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    with get_connection() as conn:
        cur = conn.execute(sql, tuple(params))
        conn.commit()
        return int(cur.lastrowid or 0)


def execute_many(sql: str, rows: list[Iterable[Any]]) -> None:
    with get_connection() as conn:
        conn.executemany(sql, rows)
        conn.commit()


def query_one(sql: str, params: Iterable[Any] = ()) -> dict[str, Any] | None:
    with get_connection() as conn:
        cur = conn.execute(sql, tuple(params))
        row = cur.fetchone()
        return dict(row) if row else None


def query_all(sql: str, params: Iterable[Any] = ()) -> list[dict[str, Any]]:
    with get_connection() as conn:
        cur = conn.execute(sql, tuple(params))
        return [dict(row) for row in cur.fetchall()]


def init_database() -> None:
    schema = Path(config.BASE_DIR / "database" / "schema.sql").read_text(encoding="utf-8")
    with get_connection() as conn:
        conn.executescript(schema)
        conn.commit()
