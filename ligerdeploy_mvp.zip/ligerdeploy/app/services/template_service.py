import shutil
from pathlib import Path
from app.core import config

TEMPLATE_META = {
    "aiogram-basic-bot": ("Telegram Bot", "Aiogram polling bot with BOT_TOKEN"),
    "aiogram-fastapi-webhook": ("Telegram Bot", "Aiogram + FastAPI webhook-ready starter"),
    "fastapi-basic-api": ("FastAPI App", "Simple API served by uvicorn"),
    "flask-basic-app": ("Flask App", "Minimal Flask app"),
    "django-basic-app": ("Django App", "Minimal Django project layout"),
    "telethon-userbot": ("UserBot / MTProto App", "Telethon session-string userbot skeleton"),
    "pyrogram-userbot": ("UserBot / MTProto App", "Pyrogram userbot skeleton"),
    "apscheduler-worker": ("Scheduler App", "APScheduler background worker"),
}


def list_templates() -> list[dict]:
    rows = []
    if not config.TEMPLATES_PATH.exists():
        return rows
    for path in sorted(config.TEMPLATES_PATH.iterdir()):
        if path.is_dir():
            title, description = TEMPLATE_META.get(path.name, (path.name, "Starter template"))
            rows.append({"slug": path.name, "title": title, "description": description, "path": path})
    return rows


def copy_template(slug: str, destination: Path) -> None:
    source = (config.TEMPLATES_PATH / slug).resolve()
    if not source.exists() or config.TEMPLATES_PATH.resolve() not in source.parents:
        raise ValueError("Template not found")
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)
