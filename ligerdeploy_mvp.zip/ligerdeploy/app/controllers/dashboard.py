from fastapi import APIRouter, Request
from app.core import auth
from app.core.views import templates, context
from app.helpers.formatters import human_bytes
from app.services import activity_service, project_service

router = APIRouter()


@router.get("/dashboard")
async def dashboard(request: Request):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    stats = project_service.counts(user)
    disk_usage = human_bytes(project_service.user_disk_usage(user))
    projects = project_service.list_projects(user)[:8]
    logs = activity_service.recent(None if user["role"] == "admin" else user["id"], 10)
    return templates.TemplateResponse("dashboard/index.html", context(request, stats=stats, disk_usage=disk_usage, projects=projects, logs=logs))
