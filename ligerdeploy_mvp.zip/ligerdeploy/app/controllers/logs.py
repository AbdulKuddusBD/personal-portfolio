from fastapi import APIRouter, Form, Request
from starlette.responses import FileResponse, RedirectResponse
from app.core import auth, csrf
from app.core.views import templates, context
from app.services import process_manager, project_service

router = APIRouter(prefix="/projects/{project_id}/logs")
LOGS = ["stdout.log", "stderr.log", "install.log"]


@router.get("")
async def index(request: Request, project_id: int, tab: str = "stdout.log"):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if not project:
        return RedirectResponse("/projects", status_code=303)
    if tab not in LOGS:
        tab = "stdout.log"
    contents = {name: process_manager.tail(project_id, name) for name in LOGS}
    return templates.TemplateResponse("logs/index.html", context(request, project=project, logs=LOGS, active=tab, contents=contents))


@router.post("/clear")
async def clear(request: Request, project_id: int, name: str = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if project and name in LOGS:
        process_manager.clear_log(project_id, name)
    return RedirectResponse(f"/projects/{project_id}/logs?tab={name}", status_code=303)


@router.get("/download")
async def download(request: Request, project_id: int, name: str):
    user = auth.get_current_user(request)
    if not user:
        return auth.redirect_to_login()
    project = project_service.get_project(project_id, user)
    if not project or name not in LOGS:
        return RedirectResponse("/projects", status_code=303)
    path = process_manager.log_file(project_id, name)
    return FileResponse(str(path), filename=f"{project['slug']}-{name}")
