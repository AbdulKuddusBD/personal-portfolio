from pathlib import Path
from fastapi import APIRouter, File, Form, Request, UploadFile
from starlette.responses import FileResponse, RedirectResponse
from app.core import auth, csrf
from app.core.views import templates, context
from app.services import file_service, project_service

router = APIRouter(prefix="/projects/{project_id}/files")


def _project(request: Request, project_id: int):
    user = auth.get_current_user(request)
    if not user:
        return None, None
    return user, project_service.get_project(project_id, user)


@router.get("")
async def index(request: Request, project_id: int, path: str = ""):
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if not project:
        return RedirectResponse("/projects", status_code=303)
    data = file_service.list_dir(project, path)
    return templates.TemplateResponse("files/index.html", context(request, project=project, data=data, error=None))


@router.post("/upload")
async def upload(request: Request, project_id: int, path: str = Form(""), files: list[UploadFile] = File(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if project:
        for upload_file in files:
            file_service.save_upload(project, path, upload_file.filename, await upload_file.read())
    return RedirectResponse(f"/projects/{project_id}/files?path={path}", status_code=303)


@router.post("/create-file")
async def create_file(request: Request, project_id: int, path: str = Form(""), name: str = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if project:
        file_service.create_file(project, path, name)
    return RedirectResponse(f"/projects/{project_id}/files?path={path}", status_code=303)


@router.post("/create-folder")
async def create_folder(request: Request, project_id: int, path: str = Form(""), name: str = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if project:
        file_service.create_folder(project, path, name)
    return RedirectResponse(f"/projects/{project_id}/files?path={path}", status_code=303)


@router.post("/delete")
async def delete_path(request: Request, project_id: int, target: str = Form(...), current: str = Form(""), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if project:
        file_service.delete_path(project, target)
    return RedirectResponse(f"/projects/{project_id}/files?path={current}", status_code=303)


@router.post("/rename")
async def rename_path(request: Request, project_id: int, target: str = Form(...), new_name: str = Form(...), current: str = Form(""), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if project:
        file_service.rename_path(project, target, new_name)
    return RedirectResponse(f"/projects/{project_id}/files?path={current}", status_code=303)


@router.post("/extract")
async def extract(request: Request, project_id: int, target: str = Form(...), current: str = Form(""), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if project:
        file_service.extract_zip(project, target)
    return RedirectResponse(f"/projects/{project_id}/files?path={current}", status_code=303)


@router.get("/edit")
async def edit_file(request: Request, project_id: int, target: str):
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if not project:
        return RedirectResponse("/projects", status_code=303)
    content = file_service.read_text(project, target)
    return templates.TemplateResponse("files/edit.html", context(request, project=project, target=target, content=content))


@router.post("/edit")
async def save_file(request: Request, project_id: int, target: str = Form(...), content: str = Form(""), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if project:
        file_service.write_text(project, target, content)
    parent = str(Path(target).parent).replace(".", "")
    return RedirectResponse(f"/projects/{project_id}/files?path={parent}", status_code=303)


@router.get("/download")
async def download(request: Request, project_id: int, target: str):
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if not project:
        return RedirectResponse("/projects", status_code=303)
    path = file_service.safe_join(Path(project["project_path"]), target)
    return FileResponse(str(path), filename=path.name)


@router.get("/backup")
async def backup(request: Request, project_id: int):
    user, project = _project(request, project_id)
    if not user:
        return auth.redirect_to_login()
    if not project:
        return RedirectResponse("/projects", status_code=303)
    backup_path = file_service.make_backup(project)
    return FileResponse(str(backup_path), filename=backup_path.name)
