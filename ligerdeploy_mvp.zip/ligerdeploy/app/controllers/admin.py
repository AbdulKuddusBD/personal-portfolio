import platform
from fastapi import APIRouter, Form, Request
from starlette.responses import RedirectResponse
from app.core import auth, csrf, database, config, security
from app.core.views import templates, context
from app.helpers.formatters import human_bytes
from app.services import project_service

router = APIRouter(prefix="/admin")


def admin_user(request: Request):
    user = auth.get_current_user(request)
    if not auth.is_admin(user):
        return None
    return user


@router.get("")
async def index(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    status = {
        "python": platform.python_version(),
        "database": str(config.DATABASE_PATH),
        "storage": str(config.STORAGE_PATH),
        "disk_usage": human_bytes(project_service.disk_usage(config.STORAGE_PATH)),
        "app_env": config.APP_ENV,
    }
    return templates.TemplateResponse("admin/system.html", context(request, status=status))


@router.get("/users")
async def users(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    rows = database.query_all("SELECT id, name, email, role, is_active, created_at FROM users ORDER BY id DESC")
    return templates.TemplateResponse("admin/users.html", context(request, users=rows))


@router.post("/users/create")
async def create_user(request: Request, name: str = Form(...), email: str = Form(...), password: str = Form(...), role: str = Form("user"), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    if role not in {"admin", "user"}:
        role = "user"
    database.execute("INSERT INTO users (name, email, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)", (name.strip(), email.lower().strip(), security.hash_password(password), role))
    return RedirectResponse("/admin/users", status_code=303)


@router.post("/users/toggle")
async def toggle_user(request: Request, user_id: int = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    if user_id != user["id"]:
        database.execute("UPDATE users SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?", (user_id,))
    return RedirectResponse("/admin/users", status_code=303)


@router.get("/projects")
async def projects(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    rows = database.query_all("SELECT projects.*, users.email AS user_email FROM projects JOIN users ON users.id = projects.user_id ORDER BY projects.id DESC")
    return templates.TemplateResponse("admin/projects.html", context(request, projects=rows))


@router.get("/settings")
async def settings(request: Request):
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    rows = database.query_all("SELECT * FROM settings ORDER BY key")
    return templates.TemplateResponse("admin/settings.html", context(request, settings=rows))


@router.post("/settings")
async def save_setting(request: Request, key: str = Form(...), value: str = Form(...), csrf_token: str = Form(...)):
    csrf.verify_csrf(request, csrf_token)
    user = admin_user(request)
    if not user:
        return auth.redirect_to_login()
    database.execute("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP", (key.strip(), value.strip()))
    return RedirectResponse("/admin/settings", status_code=303)
