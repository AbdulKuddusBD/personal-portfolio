#!/usr/bin/env python3
import getpass
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.core import database, security


def main():
    database.init_database()
    name = input("Name: ").strip() or "Admin"
    email = input("Email: ").strip().lower()
    if not email:
        raise SystemExit("Email is required")
    password = getpass.getpass("Password: ")
    if len(password) < 8:
        raise SystemExit("Password must be at least 8 characters")
    database.execute("INSERT INTO users (name, email, password_hash, role, is_active) VALUES (?, ?, ?, 'admin', 1)", (name, email, security.hash_password(password)))
    print("Admin created")

if __name__ == "__main__":
    main()
